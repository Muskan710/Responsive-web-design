const menuButton = document.getElementById("menu-Button");
const navLinks = document.getElementById("nav-links");
const menuButtonIcon = menuButton.querySelector("i");

menuButton.addEventListener("click", (e) => {
  navLinks.classList.toggle("open");

  const isOpen = navLinks.classList.contains("open");
  menuButtonIcon.setAttribute("class", isOpen ? "ri-close-line" : "ri-menu-line");
});

navLinks.addEventListener("click", (e) => {
  navLinks.classList.remove("open");
  menuButtonIcon.setAttribute("class", "ri-menu-line");
});

const navSearch = document.getElementById("nav-search");

navSearch.addEventListener("click", (e) => {
  navSearch.classList.toggle("open");
});

const scrollRevealOption = {
  distance: "50px",
  origin: "bottom",
  duration: 1000,
};

ScrollReveal().reveal(".headerimage img", {
  ...scrollRevealOption,
  origin: "right",
});
ScrollReveal().reveal(".headercontent div", {
  duration: 1000,
  delay: 500,
});
ScrollReveal().reveal(".headercontent h1", {
  ...scrollRevealOption,
  delay: 1000,
});
ScrollReveal().reveal(".headercontent p", {
  ...scrollRevealOption,
  delay: 1500,
});

ScrollReveal().reveal(".dealscard", {
  ...scrollRevealOption,
  interval: 500,
});

ScrollReveal().reveal(".aboutimage img", {
  ...scrollRevealOption,
  origin: "right",
});
ScrollReveal().reveal(".aboutcard", {
  duration: 1000,
  interval: 500,
  delay: 500,
});

const swiper = new Swiper(".swiper", {
  loop: true,
});

document.addEventListener("DOMContentLoaded", function () {
  var swiper = new Swiper(".swiper", {
    loop: true, // Enables infinite looping
    autoplay: {
      delay: 3000, // Slide changes every 3 seconds
      disableOnInteraction: false, // Keeps autoplay running after interaction
    },
    slidesPerView: 1,
    spaceBetween: 10,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
});
